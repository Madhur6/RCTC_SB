package com.example.passenger_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassengerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
