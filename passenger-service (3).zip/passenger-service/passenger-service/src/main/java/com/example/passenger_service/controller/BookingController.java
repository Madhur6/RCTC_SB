package com.example.passenger_service.controller;

import com.example.passenger_service.model.Booking;
import com.example.passenger_service.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Create a booking
    @PostMapping("/create")
    public ResponseEntity<Booking> createBooking(
            @RequestParam Long trainId, 
            @RequestParam Long coachId, 
            @RequestParam int passengerId, 
            @RequestParam int seats) {
        try {
            Booking booking = bookingService.createBooking(trainId, coachId, passengerId, seats);
            return ResponseEntity.ok(booking);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    // View all bookings
    @GetMapping("/all")
    public Iterable<Booking> getAllBookings() {
        return bookingService.getAllBookings();
    }

    // Cancel a booking
    @DeleteMapping("/cancel/{id}")
    public ResponseEntity<Void> cancelBooking(@PathVariable Long id) {
        try {
            bookingService.cancelBooking(id);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
