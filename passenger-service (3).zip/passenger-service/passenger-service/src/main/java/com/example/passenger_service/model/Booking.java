package com.example.passenger_service.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime bookingDate;  // Date and time when the booking was made
    private int seatsBooked;  // Number of seats booked

    @ManyToOne
    @JoinColumn(name = "passenger_id")
    private Passenger passenger;  // Reference to the passenger making the booking

    @ManyToOne
    @JoinColumn(name = "train_id")
    private Train train;  // Reference to the train

    @ManyToOne
    @JoinColumn(name = "coach_id")
    private Coach coach;  // Reference to the coach

    // Constructors, getters, and setters

    public Booking() {}

    public Booking(LocalDateTime bookingDate, int seatsBooked, Passenger passenger, Train train, Coach coach) {
        this.bookingDate = bookingDate;
        this.seatsBooked = seatsBooked;
        this.passenger = passenger;
        this.train = train;
        this.coach = coach;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(LocalDateTime bookingDate) {
        this.bookingDate = bookingDate;
    }

    public int getSeatsBooked() {
        return seatsBooked;
    }

    public void setSeatsBooked(int seatsBooked) {
        this.seatsBooked = seatsBooked;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public Train getTrain() {
        return train;
    }

    public void setTrain(Train train) {
        this.train = train;
    }

    public Coach getCoach() {
        return coach;
    }

    public void setCoach(Coach coach) {
        this.coach = coach;
    }
}
