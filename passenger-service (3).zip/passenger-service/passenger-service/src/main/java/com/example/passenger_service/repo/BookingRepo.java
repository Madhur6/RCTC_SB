package com.example.passenger_service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.passenger_service.model.Booking;

@Repository
public interface BookingRepo extends JpaRepository<Booking, Long> {
}
