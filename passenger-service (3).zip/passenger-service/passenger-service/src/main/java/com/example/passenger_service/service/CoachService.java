package com.example.passenger_service.service;

import com.example.passenger_service.model.Coach;
import com.example.passenger_service.repo.CoachRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CoachService {

    @Autowired
    private CoachRepo coachRepo;

    // Get all coaches
    public List<Coach> getAllCoaches() {
        return coachRepo.findAll();
    }

    // Get a coach by its ID
    public Coach getCoachById(Long id) {
        Optional<Coach> coach = coachRepo.findById(id);
        return coach.orElse(null);
    }

    // Create a new coach
    public Coach createCoach(Coach coach) {
        return coachRepo.save(coach);
    }

    // Update an existing coach
    public Coach updateCoach(Long id, Coach coach) {
        if (coachRepo.existsById(id)) {
            coach.setId(id);
            return coachRepo.save(coach);
        } else {
            return null;
        }
    }

    // Delete a coach
    public void deleteCoach(Long id) {
        if (coachRepo.existsById(id)) {
            coachRepo.deleteById(id);
        }
    }
}

