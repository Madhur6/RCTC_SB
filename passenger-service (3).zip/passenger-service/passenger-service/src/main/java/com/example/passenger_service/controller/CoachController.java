package com.example.passenger_service.controller;

import com.example.passenger_service.model.Coach;
import com.example.passenger_service.service.CoachService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/coach")
public class CoachController {

    @Autowired
    private CoachService coachService;

    // Get all coaches
    @GetMapping("")
    public List<Coach> getAllCoaches() {
        return coachService.getAllCoaches();
    }

    // Get a coach by ID
    @GetMapping("/{id}")
    public ResponseEntity<Coach> getCoachById(@PathVariable Long id) {
        Coach coach = coachService.getCoachById(id);
        if (coach != null) {
            return ResponseEntity.ok(coach);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Create a new coach
    @PostMapping("")
    public ResponseEntity<Coach> createCoach(@RequestBody Coach coach) {
        Coach createdCoach = coachService.createCoach(coach);
        return ResponseEntity.ok(createdCoach);
    }

    // Update an existing coach
    @PutMapping("/{id}")
    public ResponseEntity<Coach> updateCoach(@PathVariable Long id, @RequestBody Coach coach) {
        Coach updatedCoach = coachService.updateCoach(id, coach);
        return ResponseEntity.ok(updatedCoach);
    }

    // Delete a coach
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCoach(@PathVariable Long id) {
        coachService.deleteCoach(id);
        return ResponseEntity.noContent().build();
    }
}
