package com.example.passenger_service.service;

import com.example.passenger_service.model.Booking;
import com.example.passenger_service.model.Coach;
import com.example.passenger_service.model.Passenger;
import com.example.passenger_service.model.Train;
import com.example.passenger_service.repo.BookingRepo;
import com.example.passenger_service.repo.CoachRepo;
import com.example.passenger_service.repo.PassengerRepo;
import com.example.passenger_service.repo.TrainRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    private BookingRepo bookingRepo;
    
    @Autowired
    private TrainRepo trainRepo;
    
    @Autowired
    private CoachRepo coachRepo;

    @Autowired
    private PassengerRepo passengerRepo;


    // Create a new booking
    public Booking createBooking(Long trainId, Long coachId, int passengerId, int seats) {
        Optional<Train> trainOptional = trainRepo.findById(trainId);
        Optional<Coach> coachOptional = coachRepo.findById(coachId);
        Optional<Passenger> passengerOptional = passengerRepo.findById(passengerId);

        if (!trainOptional.isPresent() || !coachOptional.isPresent() || !passengerOptional.isPresent()) {
            throw new IllegalArgumentException("Invalid train, coach, or passenger ID");
        }

        Train train = trainOptional.get();
        Coach coach = coachOptional.get();
        Passenger passenger = passengerOptional.get();

        if (coach.getAvailableSeats() < seats) {
            throw new IllegalArgumentException("Not enough available seats in the coach");
        }

        // Update the available seats in the coach
        coach.setAvailableSeats(coach.getAvailableSeats() - seats);

        // Save the updated coach
        coachRepo.save(coach);

        // Create and save the booking
        Booking booking = new Booking(LocalDateTime.now(), seats, passenger, train, coach);
        return bookingRepo.save(booking);
    }

    // Cancel a booking (revert seat availability)
    public void cancelBooking(Long bookingId) {
        Optional<Booking> bookingOptional = bookingRepo.findById(bookingId);
        if (!bookingOptional.isPresent()) {
            throw new IllegalArgumentException("Booking not found");
        }

        Booking booking = bookingOptional.get();
        Coach coach = booking.getCoach();

        // Revert the available seats
        coach.setAvailableSeats(coach.getAvailableSeats() + booking.getSeatsBooked());

        // Save the updated coach
        coachRepo.save(coach);

        // Delete the booking
        bookingRepo.deleteById(bookingId);
    }

    // View all bookings (optional)
    public Iterable<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }
}
