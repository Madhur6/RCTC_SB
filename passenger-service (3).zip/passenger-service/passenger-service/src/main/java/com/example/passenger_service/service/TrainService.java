package com.example.passenger_service.service;

import java.util.ArrayList;
import java.util.List;

import com.example.passenger_service.model.Coach;
import com.example.passenger_service.model.Train;
import com.example.passenger_service.repo.CoachRepo;
import com.example.passenger_service.repo.TrainRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrainService {

    @Autowired
    private TrainRepo trainRepo;
    
    @Autowired
    private CoachRepo coachRepo;


    public List<Train> getAllTrains() {
        return trainRepo.findAll();
    }

 
    public Train getTrainById(Long id) {
        Optional<Train> train = trainRepo.findById(id);
        return train.orElse(null);
    }
    


    public Train createTrain(Train train) {
        return trainRepo.save(train);
    }

    
    public Train updateTrain(Long id, Train updatedTrain) {
        return trainRepo.findById(id).map(existingTrain -> {
            // Update train details
            existingTrain.setTrainNumber(updatedTrain.getTrainNumber());
            existingTrain.setTrainName(updatedTrain.getTrainName());
            existingTrain.setSource(updatedTrain.getSource());
            existingTrain.setDestination(updatedTrain.getDestination());

            if (updatedTrain.getCoaches() != null) {
                List<Coach> updatedCoaches = new ArrayList<>();

                for (Coach updatedCoach : updatedTrain.getCoaches()) {
                    if (updatedCoach.getId() != null) {

                        Coach existingCoach = coachRepo.findById(updatedCoach.getId())
                            .orElseThrow(() -> new IllegalArgumentException("Coach with ID " + updatedCoach.getId() + " not found"));
                        existingCoach.setCoachType(updatedCoach.getCoachType());
                        existingCoach.setCoachName(updatedCoach.getCoachName());
                        existingCoach.setTotalSeats(updatedCoach.getTotalSeats());
                        existingCoach.setAvailableSeats(updatedCoach.getAvailableSeats());
                        updatedCoaches.add(existingCoach);
                    } else {

                        updatedCoach.setTrain(existingTrain);
                        updatedCoaches.add(updatedCoach);
                    }
                }


                existingTrain.getCoaches().clear();
                existingTrain.getCoaches().addAll(updatedCoaches);
            }


            return trainRepo.save(existingTrain);
        }).orElseThrow(() -> new IllegalArgumentException("Train with ID " + id + " does not exist"));
    }

    
    
    public void deleteTrain(Long id) {
        if (trainRepo.existsById(id)) {
            trainRepo.deleteById(id);
        }
    }
}